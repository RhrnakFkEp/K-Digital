import mod2
result = mod2.sum(3, 4)
print(result)