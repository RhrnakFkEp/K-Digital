# render.py

# from game.sound.echo import echo_test
from ..sound.echo import echo_test
# relative(상대적인) 적용가능

def render_test():
    print("render")
    echo_test()
